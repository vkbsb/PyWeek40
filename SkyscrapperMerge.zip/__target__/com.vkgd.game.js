// Transcrypt'ed from Python, 2025-09-28 09:21:36
import {AssertionError, AttributeError, BaseException, DeprecationWarning, Exception, IndexError, IterableError, KeyError, NotImplementedError, RuntimeWarning, StopIteration, UserWarning, ValueError, Warning, __JsIterator__, __PyIterator__, __Terminal__, __add__, __and__, __call__, __class__, __envir__, __eq__, __floordiv__, __ge__, __get__, __getcm__, __getitem__, __getslice__, __getsm__, __gt__, __i__, __iadd__, __iand__, __idiv__, __ijsmod__, __ilshift__, __imatmul__, __imod__, __imul__, __in__, __init__, __ior__, __ipow__, __irshift__, __isub__, __ixor__, __jsUsePyNext__, __jsmod__, __k__, __kwargtrans__, __le__, __lshift__, __lt__, __matmul__, __mergefields__, __mergekwargtrans__, __mod__, __mul__, __ne__, __neg__, __nest__, __or__, __pow__, __pragma__, __pyUseJsNext__, __rshift__, __setitem__, __setproperty__, __setslice__, __sort__, __specialattrib__, __sub__, __super__, __t__, __terminal__, __truediv__, __withblock__, __xor__, _sort, abs, all, any, assert, bin, bool, bytearray, bytes, callable, chr, delattr, dict, dir, divmod, enumerate, filter, float, getattr, hasattr, hex, input, int, isinstance, issubclass, len, list, map, max, min, object, oct, ord, pow, print, property, py_TypeError, py_iter, py_metatype, py_next, py_reversed, py_typeof, range, repr, round, set, setattr, sorted, str, sum, tuple, zip} from './org.transcrypt.__runtime__.js';
import {ASSETS} from './com.vkgd.assets.js';
import {Game2048} from './com.vkgd.Game2048.js';
import {DESIGN_HEIGHT, DESIGN_WIDTH, EVENT_MOUSEDOWN, EVENT_MOUSEUP, EVENT_MOVE} from './com.vkgd.common.constants.js';
import {GameplayScreen} from './com.vkgd.gameplay.js';
import {LoadingScreen} from './com.vkgd.splash.js';
import {PIXI} from './com.pixi.js';
var __name__ = 'com.vkgd.game';
export var Game =  __class__ ('Game', [object], {
	__module__: __name__,
	get __init__ () {return __get__ (this, function (self) {
		var container = document.getElementById ('app');
		var app = PIXI.Application (dict ({'antialias': true, 'autoDensity': true, 'resizeTo': container}));
		self.gameOver = false;
		self.app = app;
		container.appendChild (app.view);
		self.rootStage = PIXI.Container ();
		self.app.stage.addChild (self.rootStage);
		self.onResize ();
		self.screen = LoadingScreen (self.rootStage);
		PIXI.loader.add (ASSETS);
		PIXI.loader.load (self.onAssetsLoaded);
		PIXI.Ticker.shared.add (self.py_update);
		window.addEventListener ('resize', self.onResize);
		window.addEventListener ('pointerdown', self.onMouseDown);
		window.addEventListener ('pointerup', self.onMouseUp);
		window.addEventListener ('keydown', self.onKeyDown);
	});},
	get onKeyDown () {return __get__ (this, function (self, e) {
		if (self.screen != null && hasattr (self.screen, 'game')) {
			var direction = null;
			if (e.key == 'ArrowLeft') {
				var direction = Game2048.move_left;
			}
			else if (e.key == 'ArrowRight') {
				var direction = Game2048.move_right;
			}
			else if (e.key == 'ArrowUp') {
				var direction = Game2048.move_up;
			}
			else if (e.key == 'ArrowDown') {
				var direction = Game2048.move_down;
			}
			if (direction != null) {
				self.screen.onEvent (EVENT_MOVE, direction);
			}
			e.preventDefault ();
		}
	});},
	get onMouseUp () {return __get__ (this, function (self, e) {
		var x = int ((e.clientX - self.rootStage.x) / self.scale);
		var y = int ((e.clientY - self.rootStage.y) / self.scale);
		print ('x:{}, y:{}, rx:{}, ry:{}'.format (x, y, self.rootStage.x, self.rootStage.y));
		e.preventDefault ();
		if (self.screen != null) {
			self.screen.onEvent (EVENT_MOUSEUP, tuple ([x, y]));
			var endPos = tuple ([x, y]);
			var xdiff = endPos [0] - self.startPos [0];
			var ydiff = endPos [1] - self.startPos [1];
			if (abs (xdiff) > abs (ydiff)) {
				if (xdiff > 0) {
					self.screen.onEvent (EVENT_MOVE, Game2048.move_right);
				}
				else {
					self.screen.onEvent (EVENT_MOVE, Game2048.move_left);
				}
			}
			else if (ydiff > 0) {
				self.screen.onEvent (EVENT_MOVE, Game2048.move_down);
			}
			else {
				self.screen.onEvent (EVENT_MOVE, Game2048.move_up);
			}
		}
	});},
	get onMouseDown () {return __get__ (this, function (self, e) {
		var x = int ((e.clientX - self.rootStage.x) / self.scale);
		var y = int ((e.clientY - self.rootStage.y) / self.scale);
		print ('x:{}, y:{}, rx:{}, ry:{}'.format (x, y, self.rootStage.x, self.rootStage.y));
		e.preventDefault ();
		self.screen.onEvent (EVENT_MOUSEDOWN, tuple ([x, y]));
		self.startPos = tuple ([x, y]);
	});},
	get onTouchStart () {return __get__ (this, function (self, e) {
		var touch = e.changedTouches [0];
		var x = int ((touch.clientX - self.rootStage.x) / self.scale);
		var y = int ((touch.clientY - self.rootStage.y) / self.scale);
		print ('x:{}, y:{}, rx:{}, ry:{}'.format (x, y, self.rootStage.x, self.rootStage.y));
		e.preventDefault ();
		self.screen.onEvent (EVENT_MOUSEDOWN, tuple ([x, y]));
	});},
	get onResize () {return __get__ (this, function (self) {
		var app = self.app;
		var viewW = app.renderer.width;
		var viewH = app.renderer.height;
		var scale = Math.min (viewW / DESIGN_WIDTH, viewH / DESIGN_HEIGHT);
		self.scale = scale;
		self.rootStage.scale.set (scale, scale);
		var worldWidth = DESIGN_WIDTH * scale;
		var worldHeight = DESIGN_HEIGHT * scale;
		print (scale, viewW, DESIGN_WIDTH, worldWidth, worldHeight);
		self.rootStage.x = (viewW - worldWidth) / 2;
		self.rootStage.y = (viewH - worldHeight) / 2;
	});},
	get onAssetsLoaded () {return __get__ (this, function (self, resources) {
		self.screen.cleanup ();
		print ('StageChildren: ', self.rootStage.children.length);
		self.screen = GameplayScreen (self.rootStage);
	});},
	get py_update () {return __get__ (this, function (self, dt) {
		self.screen.py_update (dt);
		if (isinstance (self.screen, GameplayScreen)) {
			if (self.screen.isComplete ()) {
				self.screen.cleanup ();
				self.screen = GameOverScreen (self.rootStage);
			}
		}
		PIXI.tweenManager.update ();
	});}
});

//# sourceMappingURL=com.vkgd.game.map