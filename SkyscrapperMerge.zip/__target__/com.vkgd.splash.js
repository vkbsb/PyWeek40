// Transcrypt'ed from Python, 2025-09-28 09:21:36
import {AssertionError, AttributeError, BaseException, DeprecationWarning, Exception, IndexError, IterableError, KeyError, NotImplementedError, RuntimeWarning, StopIteration, UserWarning, ValueError, Warning, __JsIterator__, __PyIterator__, __Terminal__, __add__, __and__, __call__, __class__, __envir__, __eq__, __floordiv__, __ge__, __get__, __getcm__, __getitem__, __getslice__, __getsm__, __gt__, __i__, __iadd__, __iand__, __idiv__, __ijsmod__, __ilshift__, __imatmul__, __imod__, __imul__, __in__, __init__, __ior__, __ipow__, __irshift__, __isub__, __ixor__, __jsUsePyNext__, __jsmod__, __k__, __kwargtrans__, __le__, __lshift__, __lt__, __matmul__, __mergefields__, __mergekwargtrans__, __mod__, __mul__, __ne__, __neg__, __nest__, __or__, __pow__, __pragma__, __pyUseJsNext__, __rshift__, __setitem__, __setproperty__, __setslice__, __sort__, __specialattrib__, __sub__, __super__, __t__, __terminal__, __truediv__, __withblock__, __xor__, _sort, abs, all, any, assert, bin, bool, bytearray, bytes, callable, chr, delattr, dict, dir, divmod, enumerate, filter, float, getattr, hasattr, hex, input, int, isinstance, issubclass, len, list, map, max, min, object, oct, ord, pow, print, property, py_TypeError, py_iter, py_metatype, py_next, py_reversed, py_typeof, range, repr, round, set, setattr, sorted, str, sum, tuple, zip} from './org.transcrypt.__runtime__.js';
import {DESIGN_HEIGHT, DESIGN_WIDTH, EVENT_MOUSEDOWN, EVENT_MOUSEUP, EVENT_MOVE} from './com.vkgd.common.constants.js';
import {Scene} from './com.vkgd.common.scene.js';
import {PIXI} from './com.pixi.js';
var __name__ = 'com.vkgd.splash';
export var LoadingScreen =  __class__ ('LoadingScreen', [Scene], {
	__module__: __name__,
	get __init__ () {return __get__ (this, function (self, rootStage) {
		Scene.__init__ (self, rootStage);
		self.graphics = PIXI.Graphics ();
		self.stage.addChild (self.graphics);
		self.time = 0;
	});},
	get drawScene () {return __get__ (this, function (self, dt) {
		self.graphics.clear ();
		self.graphics.beginFill (15158332);
		var sx = DESIGN_WIDTH / 2.0;
		var sy = DESIGN_HEIGHT / 2.0;
		var r = 20;
		var offset = 50;
		self.graphics.drawCircle (sx - offset, sy, r * Math.abs (Math.sin (self.time * 0.05)));
		self.graphics.drawCircle (sx, sy, r * Math.abs (Math.sin (self.time * 0.05 + Math.PI / 6)));
		self.graphics.drawCircle (sx + offset, sy, r * Math.abs (Math.sin (self.time * 0.05 + Math.PI / 3)));
		self.graphics.endFill ();
		self.graphics.lineStyle (4, 65480);
		self.graphics.drawRect (0, 0, DESIGN_WIDTH, DESIGN_HEIGHT);
		self.time += dt;
		// pass;
	});},
	get py_update () {return __get__ (this, function (self, dt) {
		self.drawScene (dt);
	});},
	get onEvent () {return __get__ (this, function (self, e_name, params) {
		print ('e:{}: {}'.format (e_name, params));
	});}
});

//# sourceMappingURL=com.vkgd.splash.map