// Transcrypt'ed from Python, 2025-09-28 09:21:36
import {AssertionError, AttributeError, BaseException, DeprecationWarning, Exception, IndexError, IterableError, KeyError, NotImplementedError, RuntimeWarning, StopIteration, UserWarning, ValueError, Warning, __JsIterator__, __PyIterator__, __Terminal__, __add__, __and__, __call__, __class__, __envir__, __eq__, __floordiv__, __ge__, __get__, __getcm__, __getitem__, __getslice__, __getsm__, __gt__, __i__, __iadd__, __iand__, __idiv__, __ijsmod__, __ilshift__, __imatmul__, __imod__, __imul__, __in__, __init__, __ior__, __ipow__, __irshift__, __isub__, __ixor__, __jsUsePyNext__, __jsmod__, __k__, __kwargtrans__, __le__, __lshift__, __lt__, __matmul__, __mergefields__, __mergekwargtrans__, __mod__, __mul__, __ne__, __neg__, __nest__, __or__, __pow__, __pragma__, __pyUseJsNext__, __rshift__, __setitem__, __setproperty__, __setslice__, __sort__, __specialattrib__, __sub__, __super__, __t__, __terminal__, __truediv__, __withblock__, __xor__, _sort, abs, all, any, assert, bin, bool, bytearray, bytes, callable, chr, delattr, dict, dir, divmod, enumerate, filter, float, getattr, hasattr, hex, input, int, isinstance, issubclass, len, list, map, max, min, object, oct, ord, pow, print, property, py_TypeError, py_iter, py_metatype, py_next, py_reversed, py_typeof, range, repr, round, set, setattr, sorted, str, sum, tuple, zip} from './org.transcrypt.__runtime__.js';
import {PyHowl} from './com.howler.js';
import {ASSETS, FONT_CONFIG, HEADER_FONT_CONFIG, SFX_FILES} from './com.vkgd.assets.js';
import {Game2048} from './com.vkgd.Game2048.js';
import {DESIGN_HEIGHT, DESIGN_WIDTH, EVENT_MOUSEDOWN, EVENT_MOUSEUP, EVENT_MOVE} from './com.vkgd.common.constants.js';
import {Scene} from './com.vkgd.common.scene.js';
import {PIXI} from './com.pixi.js';
var __name__ = 'com.vkgd.gameplay';
export var cellSize = 128;
export var cellSizeX = 128 + 48;
export var cellSizeY = 128 + 48;
export var gapSize = 5;
export var GameplayScreen =  __class__ ('GameplayScreen', [Scene], {
	__module__: __name__,
	get __init__ () {return __get__ (this, function (self, rootStage) {
		Scene.__init__ (self, rootStage);
		self.game = Game2048 ();
		self.gameOver = false;
		self.score = 0;
		self.graphics = PIXI.Graphics ();
		self.stage.addChild (self.graphics);
		var mymap = PIXI.Sprite (PIXI.Texture.from ('map'));
		mymap.x = DESIGN_WIDTH / 2;
		mymap.y = DESIGN_HEIGHT / 2;
		mymap.anchor.x = 0.5;
		mymap.anchor.y = 0.5;
		self.stage.addChild (mymap);
		self.disableInput = false;
		self.textDisplay = [];
		self.imgDisplay = [];
		self.sounds = dict ({});
		for (var sfx_files of SFX_FILES) {
			var py_name = sfx_files ['name'];
			var url = sfx_files ['url'];
			self.sounds [py_name] = PyHowl (dict ({'src': url, 'preload': true}));
		}
		for (var r = 0; r < self.game.size; r++) {
			var row = [];
			var imRow = [];
			for (var c = 0; c < self.game.size; c++) {
				var spr = PIXI.Sprite ();
				spr.visible = false;
				imRow.append (spr);
				self.stage.addChild (spr);
				var text = PIXI.BitmapText ('', FONT_CONFIG);
				text.visible = false;
				row.append (text);
				self.stage.addChild (text);
			}
			self.imgDisplay.append (imRow);
			self.textDisplay.append (row);
		}
		self.drawGrid ();
	});},
	get drawGrid () {return __get__ (this, function (self) {
		self.graphics.lineStyle (2, 0);
		var offsetX = (DESIGN_WIDTH - self.game.size * cellSizeX) / 2;
		var offsetY = (DESIGN_HEIGHT - self.game.size * cellSizeY) / 2;
		for (var r = 0; r < self.game.size; r++) {
			for (var c = 0; c < self.game.size; c++) {
				var x = offsetX + c * cellSizeX;
				var y = offsetY + r * cellSizeY;
				var value = self.game.board [r] [c];
				var color = (value == 0 ? 13421772 : 16763904);
				if (value != 0) {
					self.textDisplay [r] [c].text = str (value);
					self.textDisplay [r] [c].x = (x + cellSizeX / 2) - self.textDisplay [r] [c].width / 2;
					self.textDisplay [r] [c].y = ((y + cellSizeY / 2) - self.textDisplay [r] [c].height) + 6;
					var tex = PIXI.Texture.from (str (value));
					self.imgDisplay [r] [c].texture = tex;
					self.imgDisplay [r] [c].visible = true;
					self.imgDisplay [r] [c].x = x + (cellSizeX - gapSize) / 2;
					self.imgDisplay [r] [c].y = y + (cellSizeY - gapSize) / 2;
					self.imgDisplay [r] [c].anchor.x = 0.5;
					self.imgDisplay [r] [c].anchor.y = 1;
					self.imgDisplay [r] [c].width = tex.width;
					self.imgDisplay [r] [c].height = tex.height;
					print ('Set image {} at ({},{}) to size {}x{}'.format (value, r, c, tex.width, tex.height));
				}
				else {
					self.textDisplay [r] [c].visible = false;
					self.imgDisplay [r] [c].visible = false;
				}
			}
		}
	});},
	get py_update () {return __get__ (this, function (self, dt) {
		PIXI.tweenManager.update ();
		// pass;
	});},
	get getPosition () {return __get__ (this, function (self, r, c) {
		var offsetX = (DESIGN_WIDTH - self.game.size * cellSizeX) / 2;
		var offsetY = (DESIGN_HEIGHT - self.game.size * cellSizeY) / 2;
		var x = offsetX + c * cellSizeX;
		var y = offsetY + r * cellSizeY;
		var x = x + (cellSizeX - gapSize) / 2;
		var y = y + (cellSizeY - gapSize) / 2;
		return tuple ([x, y]);
	});},
	get createBlock () {return __get__ (this, function (self, r, c, value) {
		var graphics = PIXI.Sprite (PIXI.Texture.from (str (value)));
		var __left0__ = self.getPosition (r, c);
		var x = __left0__ [0];
		var y = __left0__ [1];
		graphics.x = x;
		graphics.y = y;
		print ('Creating block {} at ({},{}) -> ({},{})'.format (value, r, c, x, y));
		self.stage.addChild (graphics);
		return graphics;
	});},
	get onAnimationFinished () {return __get__ (this, function (self) {
		self.disableInput = false;
		self.drawGrid ();
	});},
	get onSlideAnimationFinished () {return __get__ (this, function (self) {
		self.drawGrid ();
		if (!(self.anyslide)) {
			self.onAnimationFinished ();
			return ;
		}
		if (self.anymerge) {
			self.sounds ['merge'].play ();
		}
		var new_tile_info = self.game.add_random_tile ();
		if (new_tile_info) {
			var __left0__ = new_tile_info;
			var r = __left0__ [0];
			var c = __left0__ [1];
			var value = __left0__ [2];
			print ('New tile {} at ({},{})'.format (value, r, c));
			var block = self.createBlock (r, c, value);
			var onCompleted = function (block) {
				return (function __lambda__ () {
					return self.stage.removeChild (block);
				});
			};
			var __left0__ = self.getPosition (r, c);
			var tx = __left0__ [0];
			var ty = __left0__ [1];
			block.x = tx;
			block.y = ty;
			block.scale.x = 0.1;
			block.scale.y = 0.1;
			var blockTween = PIXI.tweenManager.createTween (block.scale);
			blockTween.from (dict ({'x': 0.1, 'y': 0.1})).to (dict ({'x': 1, 'y': 1}));
			blockTween.time = 100;
			blockTween.on ('end', onCompleted (block));
			blockTween.start ();
			window.setTimeout (self.onAnimationFinished, 120);
		}
		else if (self.game.game_over) {
			self.onGameOver ();
		}
	});},
	get handleMoveAnimation () {return __get__ (this, function (self, mc) {
		var __left0__ = mc.source;
		var sr = __left0__ [0];
		var sc = __left0__ [1];
		var __left0__ = mc.end;
		var er = __left0__ [0];
		var ec = __left0__ [1];
		var value = mc.value;
		var block = self.createBlock (sr, sc, value);
		var __left0__ = self.getPosition (er, ec);
		var tx = __left0__ [0];
		var ty = __left0__ [1];
		var __left0__ = self.getPosition (sr, sc);
		var sx = __left0__ [0];
		var sy = __left0__ [1];
		var onCompleted = function (block) {
			return (function __lambda__ () {
				return self.stage.removeChild (block);
			});
		};
		var blockTween = PIXI.tweenManager.createTween (block);
		blockTween.from (dict ({'x': block.x, 'y': block.y})).to (dict ({'x': tx, 'y': ty}));
		blockTween.time = 100;
		blockTween.on ('end', onCompleted (block));
		blockTween.start ();
	});},
	get animateSlide () {return __get__ (this, function (self, merged_coords) {
		self.anyslide = false;
		self.disableInput = true;
		self.anymerge = false;
		for (var mc of merged_coords) {
			print ('Type: {}, Source: {}, End: {}, Value: {}'.format (mc.type, mc.source, mc.end, mc.value));
			if (mc.type == 'move') {
				var __left0__ = mc.source;
				var sr = __left0__ [0];
				var sc = __left0__ [1];
				var __left0__ = mc.end;
				var er = __left0__ [0];
				var ec = __left0__ [1];
				var value = mc.value;
				if (sr == er && sc == ec) {
					continue;
				}
				self.anyslide = true;
				self.handleMoveAnimation (mc);
			}
			else if (mc.type == 'merge') {
				var __left0__ = mc.sources [1];
				var sr = __left0__ [0];
				var sc = __left0__ [1];
				var __left0__ = mc.end;
				var er = __left0__ [0];
				var ec = __left0__ [1];
				var value = mc.value;
				if (sr == er && sc == ec) {
					var __left0__ = mc.sources [0];
					var sr = __left0__ [0];
					var sc = __left0__ [1];
				}
				self.anyslide = true;
				self.anymerge = true;
				var new_mc = dict ({'value': value, 'source': tuple ([sr, sc]), 'end': tuple ([er, ec])});
				self.handleMoveAnimation (new_mc);
			}
		}
		if (self.anyslide) {
			self.sounds ['swish'].play ();
		}
		window.setTimeout (self.onSlideAnimationFinished, 120);
	});},
	get onEvent () {return __get__ (this, function (self, e_name, params) {
		if (e_name == EVENT_MOUSEDOWN) {
			if (self.gameOver) {
				window.location.reload ();
				return ;
			}
		}
		else if (e_name == EVENT_MOVE) {
			if (self.disableInput) {
				return ;
			}
			if (self.game._check_game_over ()) {
				self.onGameOver ();
			}
			var direction = params;
			if (__in__ (direction, [Game2048.move_left, Game2048.move_right, Game2048.move_up, Game2048.move_down])) {
				self.game.display_board ();
				var __left0__ = self.game.move (direction);
				var moved = __left0__ [0];
				var score_added = __left0__ [1];
				var merged_coords = __left0__ [2];
				self.score += score_added;
				if (moved) {
					self.animateSlide (merged_coords);
					print ('Move: {}, Moved: {}, Score Added: {}, Merged: {}'.format (direction, moved, score_added, merged_coords));
				}
				self.game.display_board ();
			}
		}
	});},
	get onGameOver () {return __get__ (this, function (self) {
		print ('Game Over!');
		self.disableInput = true;
		window.score = self.score;
		self.gameOver = true;
		var graphics = PIXI.Graphics ();
		graphics.beginFill (0, 0.7);
		graphics.drawRect (0, 0, DESIGN_WIDTH, DESIGN_HEIGHT);
		graphics.endFill ();
		var txt = PIXI.BitmapText ('Game Over!', HEADER_FONT_CONFIG);
		txt.x = (DESIGN_WIDTH - txt.width) / 2;
		txt.y = (DESIGN_HEIGHT - txt.height) / 2 - 100;
		graphics.addChild (txt);
		var scoretxt = PIXI.BitmapText ('Score: {}'.format (self.score), FONT_CONFIG);
		scoretxt.x = (DESIGN_WIDTH - scoretxt.width) / 2;
		scoretxt.y = (DESIGN_HEIGHT - scoretxt.height) / 2 + 20;
		graphics.addChild (scoretxt);
		var restarttxt = PIXI.BitmapText ('Click / Tap to Restart', FONT_CONFIG);
		restarttxt.x = (DESIGN_WIDTH - restarttxt.width) / 2;
		restarttxt.y = (DESIGN_HEIGHT - restarttxt.height) / 2 + 250;
		graphics.addChild (restarttxt);
		self.stage.addChild (graphics);
		var Tween = PIXI.tweenManager.createTween (graphics);
		Tween.from (dict ({'alpha': 0})).to (dict ({'alpha': 0.7}));
		Tween.time = 500;
		Tween.start ();
	});},
	get isComplete () {return __get__ (this, function (self) {
		return false;
	});}
});

//# sourceMappingURL=com.vkgd.gameplay.map