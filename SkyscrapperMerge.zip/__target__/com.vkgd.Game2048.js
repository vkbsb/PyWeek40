// Transcrypt'ed from Python, 2025-09-28 09:21:36
var random = {};
import {AssertionError, AttributeError, BaseException, DeprecationWarning, Exception, IndexError, IterableError, KeyError, NotImplementedError, RuntimeWarning, StopIteration, UserWarning, ValueError, Warning, __JsIterator__, __PyIterator__, __Terminal__, __add__, __and__, __call__, __class__, __envir__, __eq__, __floordiv__, __ge__, __get__, __getcm__, __getitem__, __getslice__, __getsm__, __gt__, __i__, __iadd__, __iand__, __idiv__, __ijsmod__, __ilshift__, __imatmul__, __imod__, __imul__, __in__, __init__, __ior__, __ipow__, __irshift__, __isub__, __ixor__, __jsUsePyNext__, __jsmod__, __k__, __kwargtrans__, __le__, __lshift__, __lt__, __matmul__, __mergefields__, __mergekwargtrans__, __mod__, __mul__, __ne__, __neg__, __nest__, __or__, __pow__, __pragma__, __pyUseJsNext__, __rshift__, __setitem__, __setproperty__, __setslice__, __sort__, __specialattrib__, __sub__, __super__, __t__, __terminal__, __truediv__, __withblock__, __xor__, _sort, abs, all, any, assert, bin, bool, bytearray, bytes, callable, chr, delattr, dict, dir, divmod, enumerate, filter, float, getattr, hasattr, hex, input, int, isinstance, issubclass, len, list, map, max, min, object, oct, ord, pow, print, property, py_TypeError, py_iter, py_metatype, py_next, py_reversed, py_typeof, range, repr, round, set, setattr, sorted, str, sum, tuple, zip} from './org.transcrypt.__runtime__.js';
import * as __module_random__ from './random.js';
__nest__ (random, '', __module_random__);
var __name__ = 'com.vkgd.Game2048';
export var Game2048 =  __class__ ('Game2048', [object], {
	__module__: __name__,
	move_left: 'left',
	move_right: 'right',
	move_up: 'up',
	move_down: 'down',
	get __init__ () {return __get__ (this, function (self, size) {
		if (typeof size == 'undefined' || (size != null && size.hasOwnProperty ("__kwargtrans__"))) {;
			var size = 4;
		};
		if (size < 2) {
			var __except0__ = ValueError ('Board size must be at least 2.');
			__except0__.__cause__ = null;
			throw __except0__;
		}
		self.size = size;
		self.board = [];
		for (var r = 0; r < size; r++) {
			var row = [];
			for (var c = 0; c < size; c++) {
				row.append (0);
			}
			self.board.append (row);
		}
		self.score = 0;
		self.game_over = false;
		self.add_random_tile ();
		self.add_random_tile ();
	});},
	get add_random_tile () {return __get__ (this, function (self) {
		var empty_cells = [];
		for (var r = 0; r < self.size; r++) {
			for (var c = 0; c < self.size; c++) {
				if (self.board [r] [c] == 0) {
					empty_cells.append (tuple ([r, c]));
				}
			}
		}
		if (!(empty_cells)) {
			self.game_over = self._check_game_over ();
			return null;
		}
		var __left0__ = random.choice (empty_cells);
		var r = __left0__ [0];
		var c = __left0__ [1];
		var value = (random.random () < 0.9 ? 2 : 4);
		self.board [r] [c] = value;
		return tuple ([r, c, value]);
	});},
	get _slide_and_merge_line_with_tracking () {return __get__ (this, function (self, line_data) {
		var active_tiles = (function () {
			var __accu0__ = [];
			for (var data of line_data) {
				if (data [0] != 0) {
					__accu0__.append (data);
				}
			}
			return __accu0__;
		}) ();
		var new_line_values = [];
		var move_actions = [];
		var score_added = 0;
		var i = 0;
		while (i < len (active_tiles)) {
			var __left0__ = active_tiles [i];
			var current_val = __left0__ [0];
			var current_start_coord = __left0__ [1];
			if (i + 1 < len (active_tiles) && current_val == active_tiles [i + 1] [0]) {
				var merged_val = current_val * 2;
				score_added += merged_val;
				var source1 = current_start_coord;
				var source2 = active_tiles [i + 1] [1];
				var final_index_in_line = len (new_line_values);
				move_actions.append (dict ({'type': 'merge', 'value': merged_val, 'sources': [source1, source2], 'final_index': final_index_in_line}));
				new_line_values.append (merged_val);
				i += 2;
			}
			else {
				var final_index_in_line = len (new_line_values);
				move_actions.append (dict ({'type': 'move', 'value': current_val, 'source': current_start_coord, 'final_index': final_index_in_line}));
				new_line_values.append (current_val);
				i++;
			}
		}
		for (var x = 0; x < self.size - len (new_line_values); x++) {
			new_line_values.append (0);
		}
		return tuple ([new_line_values, score_added, move_actions]);
	});},
	get move () {return __get__ (this, function (self, direction) {
		if (self.game_over) {
			return tuple ([false, 0, [], null]);
		}
		var original_board = (function () {
			var __accu0__ = [];
			for (var row of self.board) {
				__accu0__.append (row.__getslice__ (null, null, 1));
			}
			return __accu0__;
		}) ();
		var total_score_added = 0;
		var all_move_details = [];
		if (__in__ (direction, tuple (['left', 'right']))) {
			var line_order = (direction == 'left' ? range (self.size) : range (self.size - 1, -(1), -(1)));
			var final_map = (direction == 'left' ? range (self.size) : range (self.size - 1, -(1), -(1)));
			for (var r = 0; r < self.size; r++) {
				var line_data = (function () {
					var __accu0__ = [];
					for (var c of line_order) {
						__accu0__.append (tuple ([self.board [r] [c], tuple ([r, c])]));
					}
					return __accu0__;
				}) ();
				var __left0__ = self._slide_and_merge_line_with_tracking (line_data);
				var new_line_values = __left0__ [0];
				var score_added = __left0__ [1];
				var move_actions = __left0__ [2];
				total_score_added += score_added;
				var final_row = (function () {
					var __accu0__ = [];
					for (var _ = 0; _ < self.size; _++) {
						__accu0__.append (0);
					}
					return __accu0__;
				}) ();
				for (var action of move_actions) {
					var final_r = r;
					var final_c = final_map [action ['final_index']];
					action ['end'] = tuple ([final_r, final_c]);
					final_row [final_c] = action ['value'];
					delete action ['final_index'];
					all_move_details.append (action);
				}
				self.board [r] = final_row;
			}
		}
		else if (__in__ (direction, tuple (['up', 'down']))) {
			var line_order = (direction == 'up' ? range (self.size) : range (self.size - 1, -(1), -(1)));
			var final_map = (direction == 'up' ? range (self.size) : range (self.size - 1, -(1), -(1)));
			for (var c = 0; c < self.size; c++) {
				var line_data = (function () {
					var __accu0__ = [];
					for (var r of line_order) {
						__accu0__.append (tuple ([self.board [r] [c], tuple ([r, c])]));
					}
					return __accu0__;
				}) ();
				var __left0__ = self._slide_and_merge_line_with_tracking (line_data);
				var new_line_values = __left0__ [0];
				var score_added = __left0__ [1];
				var move_actions = __left0__ [2];
				total_score_added += score_added;
				var final_col = (function () {
					var __accu0__ = [];
					for (var _ = 0; _ < self.size; _++) {
						__accu0__.append (0);
					}
					return __accu0__;
				}) ();
				for (var action of move_actions) {
					var final_r = final_map [action ['final_index']];
					var final_c = c;
					action ['end'] = tuple ([final_r, final_c]);
					final_col [final_r] = action ['value'];
					delete action ['final_index'];
					all_move_details.append (action);
				}
				for (var r_update = 0; r_update < self.size; r_update++) {
					self.board [r_update] [c] = final_col [r_update];
				}
			}
		}
		else {
			var __except0__ = ValueError ('Invalid direction: {}'.format (direction));
			__except0__.__cause__ = null;
			throw __except0__;
		}
		var moved = self.board != original_board;
		var new_tile_info = null;
		if (moved) {
			self.score += total_score_added;
			if (new_tile_info) {
				var __left0__ = new_tile_info;
				var r = __left0__ [0];
				var c = __left0__ [1];
				var value = __left0__ [2];
				all_move_details.append (dict ({'type': 'new_tile', 'end': tuple ([r, c]), 'value': value}));
			}
			return tuple ([moved, total_score_added, all_move_details, new_tile_info]);
		}
		else {
			self.game_over = self._check_game_over ();
			return tuple ([moved, 0, [], null]);
		}
	});},
	get _check_game_over () {return __get__ (this, function (self) {
		for (var r = 0; r < self.size; r++) {
			for (var c = 0; c < self.size; c++) {
				if (self.board [r] [c] == 0) {
					return false;
				}
			}
		}
		for (var r = 0; r < self.size; r++) {
			for (var c = 0; c < self.size; c++) {
				var value = self.board [r] [c];
				if (c + 1 < self.size && self.board [r] [c + 1] == value) {
					return false;
				}
				if (r + 1 < self.size && self.board [r + 1] [c] == value) {
					return false;
				}
			}
		}
		return true;
	});},
	get display_board () {return __get__ (this, function (self) {
		print ('-' * (self.size * 5 + 1));
		for (var row of self.board) {
			print (('|' + '|'.join ((function () {
				var __accu0__ = [];
				for (var val of row) {
					__accu0__.append ((val != 0 ? '{}'.format (val) : '    '));
				}
				return py_iter (__accu0__);
			}) ())) + '|');
			print ('-' * (self.size * 5 + 1));
		}
		print ('Score: {}\n'.format (self.score));
	});}
});
if (__name__ == '__main__') {
	var game = Game2048 (__kwargtrans__ ({size: 4}));
	print ('--- Game Start ---');
	game.display_board ();
	while (!(game.game_over)) {
		print ('Enter move (w/a/s/d):');
		var move_input = input ().lower ();
		if (move_input == 'q') {
			break;
		}
		var direction_map = dict ({'w': 'up', 'a': 'left', 's': 'down', 'd': 'right'});
		var direction = direction_map.py_get (move_input);
		if (!(direction)) {
			print ('Invalid input. Use w, a, s, or d.');
			continue;
		}
		var __left0__ = game.move (direction);
		var moved = __left0__ [0];
		var score_added = __left0__ [1];
		var move_details = __left0__ [2];
		var new_tile_info = __left0__ [3];
		if (moved) {
			print ("\n--- Move '{}' executed! ---".format (direction));
			print ('Score added: {}'.format (score_added));
			if (move_details) {
				print ('\n--- Move Details ---');
				for (var detail of move_details) {
					if (detail ['type'] == 'move') {
						print ('  > Move: {} from {} to {}'.format (detail ['value'], detail.py_get ('source'), detail ['end']));
					}
					else if (detail ['type'] == 'merge') {
						print ('  > MERGE: {} combined into {} at {}'.format (detail ['sources'], detail ['value'], detail ['end']));
					}
					else if (detail ['type'] == 'new_tile') {
						print ('  > NEW TILE: {} placed at {}'.format (detail ['value'], detail ['end']));
					}
				}
			}
			game.display_board ();
		}
		else {
			print ('No tiles moved or merged. Try a different direction.');
			game.game_over = game._check_game_over ();
		}
		if (game.game_over) {
			print ('GAME OVER! Final Score:', game.score);
		}
	}
}

//# sourceMappingURL=com.vkgd.Game2048.map