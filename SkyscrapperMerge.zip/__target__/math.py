pi = Math.PI
e = Math.E

exp = Math.exp

def expm1 (x):      # IE workaround
    return Math.exp (x) - 1

def log (x, base):
    return Math.log (x) if base is js_undefined else Math.log (x) / Math.log (base)

def log1p (x):      # IE workaround
    return Math.log (x + 1)

def log2 (x):       # IE workaround
    return Math.log (x) / Math.LN2
    
def log10 (x):      # IE workaround
    return Math.log (x) / Math.LN10

pow = Math.pow
sqrt = Math.sqrt

sin = Math.sin
cos = Math.cos
tan = Math.tan

asin = Math.asin
acos = Math.acos
atan = Math.atan
atan2 = Math.atan2

hypot = Math.hypot
    
def degrees (x):
    return x * 180 / Math.PI
    
def radians (x):
    return x * Math.PI / 180
    
sinh = Math.sinh
cosh = Math.cosh
tanh = Math.tanh

asinh = Math.asinh
acosh = Math.acosh
atanh = Math.atanh

floor = Math.floor
ceil = Math.ceil
trunc = Math.trunc

def copysign (x, y):
    return x if Math.sign(x) == Math.sign(y) else -x

#__pragma__ ('kwargs')
def isclose (a, b, rel_tol=1e-09, abs_tol=0.0):
    return Math.abs(a-b) <= Math.max(rel_tol * Math.max(Math.abs(a), Math.abs(b)), abs_tol)
#__pragma__ ('nokwargs')

isnan = js_isNaN

inf = js_Infinity
nan = js_NaN

def modf(n):
    sign = 1 if n >= 0 else -1
    f, mod = divmod (abs(n), 1)
    return mod * sign, f * sign
