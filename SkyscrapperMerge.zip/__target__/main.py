from com.vkgd.game import Game
Game()